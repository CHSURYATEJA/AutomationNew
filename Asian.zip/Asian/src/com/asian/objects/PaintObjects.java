package com.asian.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class PaintObjects {
	//Declaring variables globally
    private static WebDriver driver;  
    /*Locators for Interior paints, Exterior paints, waterproofing, wood, metal , Paint Budget Calculator 
    Area, Enquire now , Indeas gallery, living room, White room, Wallpapers, Interior textures, Palmwave, Pincode, Check, Add to cart, Buynow*/
    static By button_InteriorPaints = By.xpath("//*[@id=\"PAINTPRODUCTS\"]/li[1]/a");
    static By button_ExteriorPaints = By.xpath("//*[@id=\"PAINTPRODUCTS\"]/li[2]/a");
    static By button_WaterProofing = By.xpath("//*[@id=\"PAINTPRODUCTS\"]/li[3]/a");
    static By button_Wood = By.xpath("//*[@id=\"PAINTPRODUCTS\"]/li[4]/a");
    static By button_Metal = By.xpath("//*[@id=\"PAINTPRODUCTS\"]/li[5]/a");
    static By button_PaintBudgetCalculator = By.xpath("//*[@id=\"TOOLS\"]/li[1]/a");
    static By textbox_Area = By.xpath("//*[@id=\"budget-calculator-comp\"]/div/div[2]/div[1]/div/div/div[1]/div[1]/form/div/div[1]/input");
    static By button_EnquireNow = By.xpath("//*[@id=\"budget-calculator-comp\"]/div/div[2]/div[1]/div/div/div[1]/div[1]/form/div/div[2]/a");
    static By button_IdeasGallery = By.xpath("/html/body/div[1]/div/div[1]/div/div/header/div[2]/div[3]/nav/div[3]/div[1]/div[2]/div/div/div[3]/ul/li[2]/a");
    static By button_Livingroom = By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div/div/div/div[2]/div[1]/a/div[1]/img");
    static By button_Whiteroom = By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div[1]/div/div[2]/div[3]/div[1]/a/div/img");
    static By button_Wallpapers = By.xpath("//*[@id=\"EXPLORECOLOURS\"]/li[4]/a");
    static By button_InteriorTexture = By.xpath("//*[@id=\"EXPLORECOLOURS\"]/li[2]/a");
    static By button_PalmWeave = By.xpath("//*[@id=\"plpListing\"]/section[2]/div[2]/ul/li[1]/a/span");
    static By textbox_Pin = By.xpath("//*[@id=\"checkPincode\"]");
    static By button_Check = By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div[8]/div/form/div[1]/div[1]/button");
    static By button_Addtocart = By.xpath("//*[@id=\"add-to-cart-click\"]");
    static By button_BuyNow = By.xpath("//*[@id=\"buy-now-click\"]");
    //Applying constructor
    public PaintObjects(WebDriver driver) {
        this.driver = driver;
    }
    //Method to Hover over on Paints and textures
    public void hoverOverElement(By by) {
        WebElement element = driver.findElement(by);
        Actions actions = new Actions(driver);
        actions.moveToElement(element).perform();
    }
    //Method to find Interior Button
	public static void clickInteriorPaintsButton() {
		Assert.assertTrue(driver.findElement(button_InteriorPaints).isDisplayed(), "\" IntButton\" Button is displayed");
		driver.findElement (button_InteriorPaints).click();
	}
	//Method to find Exterior button
	public static void clickExteriorPaintsButton() {
		Assert.assertTrue(driver.findElement(button_ExteriorPaints).isDisplayed(), "\" ExtButton\" Button is displayed");
		driver.findElement (button_ExteriorPaints).click();
	}
	//Method to find Water proofing Button
	public static void clickWaterProofingButton() {
		Assert.assertTrue(driver.findElement(button_WaterProofing).isDisplayed(), "\" WaterButton\" Button is displayed");
		driver.findElement (button_WaterProofing).click();	
	}
	//Method to find Wood button
	public static void clickWoodButton() {
		Assert.assertTrue(driver.findElement(button_Wood).isDisplayed(), "\" WoodButton\" Button is displayed");
		driver.findElement (button_Wood).click();
	}
	//Method to find Metal button
	public static void clickMetalButton() {
		Assert.assertTrue(driver.findElement(button_Metal).isDisplayed(), "\" MetalButton\" Button is displayed");
		driver.findElement (button_Metal).click();
	}
	//Method to find Paint budget calculator
	public static void clickPaintBudgetCalculatorButton() {
		Assert.assertTrue(driver.findElement(button_PaintBudgetCalculator).isDisplayed(), "\" CalcButton\" Button is displayed");
		driver.findElement (button_PaintBudgetCalculator).click();
	}
	//Method to find Area box
	public static void setTextInAreaBox(String string) {
		Assert.assertTrue(driver.findElement(textbox_Area).isDisplayed(), "\" Text\" Text is displayed");
		driver.findElement (textbox_Area).sendKeys("1200");
	}
	//Method to find Enquirenow Button
	public static void clickEnquireNowButton() {
		Assert.assertTrue(driver.findElement(button_EnquireNow).isDisplayed(), "\" EnqButton\" Button is displayed");
		driver.findElement (button_EnquireNow).click();
	}
	//Method to find Ideas Gallery Button
	public static void clickIdeasGalleryButton() {
		Assert.assertTrue(driver.findElement(button_IdeasGallery).isDisplayed(), "\" IdeasButton\" Button is displayed");
		driver.findElement(button_IdeasGallery).click();
	}
	//Method to find Living room button
	public static void clickLivingroomButton() {
		Assert.assertTrue(driver.findElement(button_Livingroom).isDisplayed(), "\" LivButton\" Button is displayed");
		driver.findElement(button_Livingroom).click();				
	}
	//Method to find White room
	public static void clickWhiteroomButton() {
		Assert.assertTrue(driver.findElement(button_Whiteroom).isDisplayed(), "\" WhiteButton\" Button is displayed");
		driver.findElement(button_Whiteroom).click();
	}
	//Method to find Wall papers
	public static void clickWallpapersButton() {
		Assert.assertTrue(driver.findElement(button_Wallpapers).isDisplayed(), "\" WallButton\" Button is displayed");
		driver.findElement(button_Wallpapers).click();
	}
	//Method to find Interior Texture button
	public static void clickInteriorTextureButton() {
		Assert.assertTrue(driver.findElement(button_InteriorTexture).isDisplayed(), "\" IntButton\" Button is displayed");
		driver.findElement(button_InteriorTexture).click();
	}
	//Method to find Palmweave button
	public static void clickPalmWeaveButton() {
		Assert.assertTrue(driver.findElement(button_PalmWeave).isDisplayed(), "\" PalmButton\" Button is displayed");
		driver.findElement(button_PalmWeave).click();
	}
	//Method to find Pincode bpx
	public static void setTextInPinBox() {
		Assert.assertTrue(driver.findElement(textbox_Pin).isDisplayed(), "\" Text\" Text is displayed");
		driver.findElement(textbox_Pin).sendKeys("110001");
	}
	//Method to find Check button
	public static void clickCheckButton() {
		Assert.assertTrue(driver.findElement(button_Check).isDisplayed(), "\" CheckButton\" Button is displayed");
		driver.findElement(button_Check).click();
	}
	//Method to find Addto cart button
	public static void clickAddtocartButton() {
		Assert.assertTrue(driver.findElement(button_Addtocart).isDisplayed(), "\" AddButton\" Button is displayed");
		driver.findElement(button_Addtocart).click();
	}
	//Method to find Buynow button
	public static void clickBuyNowButton() {
		Assert.assertTrue(driver.findElement(button_BuyNow).isDisplayed(), "\" BuyButton\" Button is displayed");
		driver.findElement(button_BuyNow).click();
	}
}
